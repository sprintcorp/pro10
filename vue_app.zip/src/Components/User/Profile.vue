<template>
    <div class="container">
        <div class="user_profile">
            <h3>User information</h3>
            <ul>
                <li><span>Name:</span> {{ userName }}</li>
                <li><span>Last name:</span> {{ lastName }}</li>
                <li><span>User Id:</span> {{ userId }}</li>
            </ul>
            <hr>
            <h3>Parent</h3>
            <ul>
                <li v-for="(key,value,index) in userParent" :key="index">
                    <span>{{value}}</span>
                    {{ key }}
                </li>
            </ul>
            <button @click="updateName">Change</button>
            <button @click="updateLastName('Timi')">Change LN</button>
        </div>
    </div>
</template>
<script>
    export default {
        props:{
            userName:String,
            lastName:String,
            userId:Number,
            userParent:Object,
            updateLastName:Function
        },
        methods:{
            updateName(){
                this.$emit('updateName','Frederick')
            },

        },
    }
</script>

<style>
    span{
        font-weight: 800;
    }
    .user_profile{
        border: 1px solid #2196f3;
        padding: 10px 20px;
    }
</style>