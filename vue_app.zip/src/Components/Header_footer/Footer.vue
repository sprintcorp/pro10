<template>
    <footer>Footer</footer>
</template>

<style>
    footer {
        background: #2196f3;
        padding: 20px;
        color: #fff;
        font-size: 30px;
    }
</style>