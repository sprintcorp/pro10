<template>
    <div>
    <header>Header</header>
    </div>
</template>

<style scoped>
    header{
        background:#2196f3;
        border-bottom: 4px solid #607d8b;
        box-sizing: border-box;
        padding: 30px;
        color: #fff;
        font-size: 30px;
    }
</style>